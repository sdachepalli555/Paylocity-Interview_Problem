﻿namespace PCTY.BusinessService
{
    public static class Constants
    {
        public const int EmployeeBenefitCost = 1000;
        public const int DependentBenefitCost = 500;

        public const int DiscountOfPersonWithNameStartsA = 10;

        public const int NumberofPayPeriods = 26;
    }
}
